# One Page Website
Hi, this is a one-page website that I designed from scratch with the help of a Figma design. I have also created video tutorials on the complete process of development.

Here is the link to the complete playlist on YouTube:
https://www.youtube.com/playlist?list=PL0-e1OMq5RP7M13Ak3v8kLW2Zp3AR26qv

Take a look at the demo: https://godsont.github.io/One-Page-Website/
